import 'package:flutter/material.dart';

var primaryColor = Color.fromARGB(255, 138, 60, 55);
var secondaryColor = Color.fromARGB(255, 124, 75, 73);